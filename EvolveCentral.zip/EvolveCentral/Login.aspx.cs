﻿using System;
using System.Linq;

namespace EvolveCentral
{
    public partial class Login : System.Web.UI.Page
    {
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session[Common.Constant.CODE_SESSION_USERID] = null;

                Session[Common.Constant.CODE_SESSION_USERNAME] = null;
                Session[Common.Constant.CODE_SESSION_ROLENAME] = null;
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblError.Text = null;
          
            int? userid = null;
            int? roleid = null;
         
            DAL.UserItem item = DAL.User.Login(ctx, txtUsername.Text, txtPassword.Text);
          
            if (item != null)
            {
                Session[Common.Constant.CODE_SESSION_USERID] = item.Id;
                Session[Common.Constant.CODE_SESSION_USERNAME] = item.Name;
                Session[Common.Constant.CODE_SESSION_ROLENAME] = item.RoleItem.Name;

                if (item.RoleItem.Name.ToUpper() == Common.Constant.CODE_ROLE_USER) Response.Redirect("administration/UserList.aspx", true);



                if (item.RoleItem.Name.ToUpper() == Common.Constant.CODE_ROLE_ADMINISTRATOR || item.RoleItem.Name.ToUpper() == Common.Constant.CODE_ROLE_SUPERADMINISTRATOR) Response.Redirect("administration/UserList.aspx", true);
            }
            else
            {
                lblError.Text = "Ïncorrect user credentials!";

            }
        }
       
    }
}