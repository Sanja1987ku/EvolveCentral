﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace EvolveCentral.Common
{
    public class Encryption
    {
        public static string EncryptString(string Message)
        {
            MD5 md5 = new MD5CryptoServiceProvider();


            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(Message));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {

                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
    }
}