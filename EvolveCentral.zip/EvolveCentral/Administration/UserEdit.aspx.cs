﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace EvolveCentral.Administration
{
    public partial class UserEdit : System.Web.UI.Page
    {
        int? id = null;
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();
    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                id = Convert.ToInt32(Request.QueryString["Id"]);
            
            if (!IsPostBack)
            {
               
                LoadData();
            }
        }

        void LoadData()
        {
            FillRoles();
            FillClients();
            if (id != null)
            {
                txtId.Enabled = false;

                DAL.UserItem item = DAL.User.GetByID(ctx, (Int32)id);
              
                txtEmail.Text = item.Email;
                txtId.Text = item.Id.ToString();
                txtName.Text = item.Name;
                txtPassword.Enabled = false;                
                txtUsername.Text = item.Username;
                chkActive.Checked = item.Active;
                ddlRole.SelectedValue = item.RoleId.ToString();
                txtId.Text = item.Id.ToString();
                txtName.Text = item.Name;
                chkActive.Checked = (Boolean)item.Active;
                if (item.ClientId != null)
                {
                    rcbClient.Enabled = true;
                    rcbClient.SelectedValue = item.ClientId.ToString();

                }
            }           
     
       
        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {

        }

        bool isValid()
        {
            bool retval = true;

            return retval;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                if (id != null)
                {
                    DAL.UserItem item = DAL.User.GetByID(ctx, (Int32)id);
                    item.Active = chkActive.Checked;                   
                    item.Email = txtEmail.Text;
                    item.Name = txtName.Text;                  
                    item.RoleId = Convert.ToInt32(ddlRole.SelectedValue);
                    item.Username = txtUsername.Text;
                    if (rcbClient.Enabled)
                        item.ClientId = Convert.ToInt32(rcbClient.SelectedValue);
                    else
                        item.ClientId = null;
                            
                            DAL.User.Save(ctx, item);

                    Response.Redirect(Request.QueryString["returnurl"]);
                }
                else
                {
                    DAL.UserItem item = new DAL.UserItem();
                    item.Active = chkActive.Checked;                   
                    item.Email = txtEmail.Text;
                    item.Name = txtName.Text;                  
                    item.RoleId = Convert.ToInt32(ddlRole.SelectedValue);
                    item.Username = txtUsername.Text;
                    item.Password = Common.Encryption.EncryptString(txtPassword.Text);
                    if (rcbClient.Enabled)
                        item.ClientId = Convert.ToInt32(rcbClient.SelectedValue);
                    else
                        item.ClientId = null;
                    DAL.User.Save(ctx, item);

                    Response.Redirect(Request.QueryString["returnurl"]);
                }

            }
        }

        void FillRoles()
        {
            ddlRole.DataSource = DAL.Role.GetAll(ctx);
            ddlRole.DataValueField = "Id";
            ddlRole.DataTextField = "Name";
            ddlRole.DataBind();

        }

        void FillClients()
        {
            rcbClient.DataSource = DAL.Client.GetAll(ctx);
            rcbClient.DataValueField = "Id";
            rcbClient.DataTextField = "Name";
            rcbClient.DataBind();

        }


    
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.QueryString["returnurl"]);
        }

        protected void ddlRole_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            DAL.RoleItem role = DAL.Role.GetByID(ctx,Convert.ToInt32(ddlRole.SelectedValue));
            if (role != null)
                if (role.Code == Common.Constant.CODE_ROLE_USER)
                {
                    rcbClient.Enabled = true;

                }
                else
                    rcbClient.Enabled = false;
        }
    }
}