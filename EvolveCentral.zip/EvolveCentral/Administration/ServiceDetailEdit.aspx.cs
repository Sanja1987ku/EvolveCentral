﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace EvolveCentral.Administration
{
    public partial class ServiceDetailEdit : System.Web.UI.Page
    {
        int? id = null;
        int? serviceid = null;

        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();
    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                id = Convert.ToInt32(Request.QueryString["Id"]);

            if (Request.QueryString["serviceid"] != null && !string.IsNullOrEmpty(Request.QueryString["serviceid"]))
                serviceid = Convert.ToInt32(Request.QueryString["serviceid"]);
         
            if (!IsPostBack)
            {
              
                LoadData();
            }
        }

        void LoadData()
        {
            if (id != null)
            {
                txtId.Enabled = false;

                DAL.ServiceDetailItem item = DAL.ServiceDetail.GetByID(ctx, (Int32)id);
              
              
                txtId.Text = item.Id.ToString();
                txtName.Text = item.Name;
           txtCommand.Text = item.Command;
           txtSequence.Text = item.Sequence.ToString();
                chkActive.Checked = item.Active;
                txtCommandType.Text = item.CommandType;
                txtDescription.Text = item.Description;
                txtDestinationTable.Text = item.DestinationTable;
                txtSourceTable.Text = item.SourceTable;

            }
        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {
        }

        bool isValid()
        {
            bool retval = true;

            return retval;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                DAL.ServiceDetailItem item = new DAL.ServiceDetailItem();

                item.CreatedBy = DAL.User.GetCurrentUser(ctx).Id;
                item.CreatedOn = DateTime.Now;

                if (id != null)
                    item = DAL.ServiceDetail.GetByID(ctx, (Int32)id);

                item.Active = chkActive.Checked;                   
              
                item.Name = txtName.Text;
                item.Command = txtCommand.Text;
                item.ServiceId = serviceid;
                item.Sequence = Convert.ToInt32(txtSequence.Text); 
                item.ModifiedBy = DAL.User.GetCurrentUser(ctx).Id;
                item.ModifiedOn = DateTime.Now;
                item.CommandType = txtCommandType.Text;
                item.Description = txtDescription.Text;
                item.DestinationTable = txtDestinationTable.Text;
                item.SourceTable = txtSourceTable.Text;
               
             


                DAL.ServiceDetail.Save(ctx, item);

                Response.Redirect("ServiceDetailList.aspx?id=" + serviceid);
            }
            
        }

       
    
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ServiceDetailList.aspx?id=" + serviceid);
        }


       

       
    
    }
}