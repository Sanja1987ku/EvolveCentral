﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace EvolveCentral.Administration
{
    public partial class ClientEdit : System.Web.UI.Page
    {
        int? id = null;
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();
    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                id = Convert.ToInt32(Request.QueryString["Id"]);
            
            if (!IsPostBack)
            {
                LoadData();
            }
        }

        void LoadData()
        {
            if (id != null)
            {
                txtId.Enabled = false; 
                
                DAL.ClientItem item = DAL.Client.GetByID(ctx, (Int32)id);
              
                txtCode.Text = item.Code;
                txtId.Text = item.Id.ToString();
                txtName.Text = item.Name;
                txtContact.Text = item.Contact;
                chkActive.Checked = item.Active;
            }
        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {
        }

        bool isValid()
        {
            bool retval = true;

            return retval;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                DAL.ClientItem item = new DAL.ClientItem();
                
                if (id != null)
                    item = DAL.Client.GetByID(ctx, (Int32)id);

                item.Active = chkActive.Checked;                   
                item.Code = txtCode.Text;
                item.Name = txtName.Text;
                item.Contact = txtContact.Text;
                            
                DAL.Client.Save(ctx, item);

                Response.Redirect(Request.QueryString["returnurl"]);
            }
            
        }

       
    
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.QueryString["returnurl"]);
        }

     
    }
}