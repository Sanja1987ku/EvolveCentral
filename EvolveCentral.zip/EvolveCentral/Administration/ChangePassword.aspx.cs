﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
namespace EvolveCentral.Administration
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        int? id = null;
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                id = Convert.ToInt32(Request.QueryString["Id"]);
            if (!IsPostBack) LoadData();
        }

        void LoadData()
        {

        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {

        }

        bool isValid()
        {

            bool isPasswordCorrect = true;
            if (!isPasswordCorrect)
            {

                return false;
            }

            return false;





        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                if (id != null)
                {
                    DAL.UserItem item = DAL.User.GetByID(ctx, (Int32)id);
                    item.Password = Common.Encryption.EncryptString(txtNewPassword1.Text);


                    DAL.User.Save(ctx, item);
                    Response.Redirect(Request.QueryString["returnurl"]);
                }


            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.QueryString["returnurl"]);
        }

   
    }
}