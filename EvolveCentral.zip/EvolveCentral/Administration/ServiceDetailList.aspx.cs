﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
namespace EvolveCentral.Administration
{
    public partial class ServiceDetailList : System.Web.UI.Page
    {
        int? serviceid = null; 
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!isAuth()) Response.Redirect("~\\Login.aspx");

            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                serviceid = Convert.ToInt32(Request.QueryString["Id"]);
          
        }
        bool isAuth()
        {
            if (Session[Common.Constant.CODE_SESSION_USERNAME] == null || String.IsNullOrEmpty(Session[Common.Constant.CODE_SESSION_USERNAME].ToString()))
                return false;

            if (Session[Common.Constant.CODE_SESSION_ROLENAME].ToString().ToUpper() != Common.Constant.CODE_ROLE_ADMINISTRATOR && Session[Common.Constant.CODE_SESSION_ROLENAME].ToString().ToUpper() != Common.Constant.CODE_ROLE_SUPERADMINISTRATOR)
                return false;

            return true;

        }
        void LoadData()
        {

        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {

        }


        protected void rgvData_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {

            
            rgvData.DataSource = DAL.ServiceDetail.GetByService(ctx,Convert.ToInt32(serviceid));
        }







        protected void rgvData_ItemCommand(object source, GridCommandEventArgs e)
        {
            string id = null;
           

           

            switch (e.CommandName)
            {
                case "Edit":

                    id = ((GridDataItem)e.Item)["Id"].Text;
                    Page.Response.Redirect("ServiceDetailEdit.aspx?Id=" + id + "&serviceid=" + serviceid + "&returnurl=ServiceDetailList.aspx", true);
                    break;

                case "InitInsert":

                    Page.Response.Redirect("ServiceDetailEdit.aspx?serviceid=" + serviceid + "&returnurl=ServiceDetailList.aspx", true);
                    break;
                case "Delete":



                    id = ((GridDataItem)e.Item)["Id"].Text;
                    DAL.ServiceDetail.Delete(ctx, Convert.ToInt32(id));

                    break;
                case "Copy":



                    id = ((GridDataItem)e.Item)["Id"].Text;
                    DAL.ServiceDetailItem i = DAL.ServiceDetail.GetByID(ctx, Convert.ToInt32(id));

                    string command = i.Command;
                    command = command.Replace("sourceDatabaseName",i.ServiceItem.SourceDatabaseName);
                                 command = command.Replace("destinationDatabaseName",i.ServiceItem.DestinationDatabaseName);
                                 RadWindowManager1.RadAlert(i.Command,null,null,null,null);
                    break;
                default:

                    break;
            }
            rgvData.DataSource = null;
        }


        
    }
}