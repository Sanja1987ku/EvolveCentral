﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace EvolveCentral.Administration
{
    public partial class ServiceEdit : System.Web.UI.Page
    {
        int? id = null;
        DAL.entitiesEvolveCentral ctx = new DAL.entitiesEvolveCentral();
    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Id"] != null && !string.IsNullOrEmpty(Request.QueryString["Id"]))
                id = Convert.ToInt32(Request.QueryString["Id"]);
            
            if (!IsPostBack)
            {
                FillServiceTypes();
                FillClients();
                LoadData();
            }
        }

        void LoadData()
        {
            if (id != null)
            {
                txtId.Enabled = false;

                DAL.ServiceItem item = DAL.Service.GetByID(ctx, (Int32)id);
              
              
                txtId.Text = item.Id.ToString();
                txtName.Text = item.Name;
                txtSourceDatabaseName.Text = item.SourceDatabaseName;
                txtDestinationDatabaseName.Text = item.DestinationDatabaseName;
                txtDescription.Text = item.Description;
                rcbClient.SelectedValue = item.ClientId.ToString();
                rcbServiceType.SelectedValue = item.ServiceTypeId.ToString();
                chkActive.Checked = item.Active;
                txtSourceDatabaseConnectionString.Text = item.SourceDatabaseConnectionString;
                txtDestinationDatabaseConnectionString.Text = item.DestinationDatabaseConnectionString;
            }
        }

        protected void rgvData_Unload(object sender, EventArgs e)
        {
        }

        bool isValid()
        {
            bool retval = true;

            return retval;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                DAL.ServiceItem item = new DAL.ServiceItem();

                item.CreatedBy = DAL.User.GetCurrentUser(ctx).Id;
                item.CreatedOn = DateTime.Now;

                item.CreatedBy = DAL.User.GetCurrentUser(ctx).Id;
                item.CreatedOn = DateTime.Now;

                if (id != null)
                    item = DAL.Service.GetByID(ctx, (Int32)id);

                item.Active = chkActive.Checked;                   
              
                item.Name = txtName.Text;
                item.ClientId = Convert.ToInt32(rcbClient.SelectedValue);
              
                item.Description = txtDescription.Text;
                item.DestinationDatabaseName = txtDestinationDatabaseName.Text;
                item.ModifiedBy = DAL.User.GetCurrentUser(ctx).Id;
                item.ModifiedOn = DateTime.Now;
                item.ServiceTypeId = Convert.ToInt32(rcbServiceType.SelectedValue);
                item.SourceDatabaseName = txtSourceDatabaseName.Text;
                item.SourceDatabaseConnectionString = txtSourceDatabaseConnectionString.Text;
                item.DestinationDatabaseConnectionString = txtDestinationDatabaseConnectionString.Text;
         
                DAL.Service.Save(ctx, item);

                if (id == null)
                {
                    if (DAL.ServiceType.GetByID(ctx,Convert.ToInt32(item.ServiceTypeId)).Code == "CRM_EVOLUTION")
                    {
                       DAL.ServiceItem defaultserviceitem = DAL.Service.GetByCode(ctx, "DEFAULT", "CRM_EVOLUTION");
                       List<DAL.ServiceDetailItem> defaultserviceitems = defaultserviceitem.ServiceDetailItems.ToList();
                 int cuserid =        DAL.User.GetCurrentUser(ctx).Id;
                 DateTime cdate =   DateTime.Now;
                        
                        foreach (DAL.ServiceDetailItem i in defaultserviceitems)
                       {
                           DAL.ServiceDetailItem sitem = new DAL.ServiceDetailItem();
                           sitem.Active = i.Active;
                           sitem.Code = i.Code;
                           sitem.Command = i.Command;
                           sitem.CommandType = i.CommandType;
                           sitem.CreatedBy = cuserid;
                           sitem.CreatedOn = cdate;
                           sitem.Description = i.Description;
                           sitem.DestinationTable = i.DestinationTable;
                           sitem.ModifiedBy = cuserid;
                           sitem.ModifiedOn = cdate;
                           sitem.Name = i.Name;
                           sitem.Sequence = i.Sequence;
                           sitem.ServiceId = item.Id;
                           sitem.SourceTable = i.SourceTable;
                           DAL.ServiceDetail.Save(ctx, sitem);


                       }
                    }
                }

                Response.Redirect(Request.QueryString["returnurl"]);
            }
            
        }

       
    
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.QueryString["returnurl"]);
        }


        void FillServiceTypes()
        {
            rcbServiceType.DataSource = DAL.ServiceType.GetAll(ctx);
            rcbServiceType.DataValueField = "Id";
            rcbServiceType.DataTextField = "Name";
            rcbServiceType.DataBind();

        }

        void FillClients()
        {
            rcbClient.DataSource = DAL.Client.GetAll(ctx);
            rcbClient.DataValueField = "Id";
            rcbClient.DataTextField = "Name";
            rcbClient.DataBind();

        }
    
    }
}