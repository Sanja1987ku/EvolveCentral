﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public class User
    {

        public static List<UserItem> GetAll(entitiesEvolveCentral ctx)
        {
            List<UserItem> items = new List<UserItem>();

            items = (from i in ctx.UserItems orderby i.Name ascending select i).ToList();



            return items;
        }

        public static UserItem GetByID(entitiesEvolveCentral ctx, int id)
        {
            UserItem item = new UserItem();

            item = (from i in ctx.UserItems where i.Id == id orderby i.Name ascending select i).FirstOrDefault();



            return item;
        }
        public static bool CheckPassword(entitiesEvolveCentral ctx, int userid, string password)
        {
            password = Common.Encryption.EncryptString(password);
            UserItem item = new UserItem();

            item = (from i in ctx.UserItems where i.Id == userid && i.Password == password orderby i.Name ascending select i).FirstOrDefault();
            if (item != null)
                return true;

            return false;


        }
        public static UserItem GetCurrentUser(entitiesEvolveCentral ctx)
        {
            UserItem item = new UserItem();
            int? id = null;

            if (HttpContext.Current.Session[Common.Constant.CODE_SESSION_USERID] != null && !string.IsNullOrEmpty(HttpContext.Current.Session[Common.Constant.CODE_SESSION_USERID].ToString()))
                id = Convert.ToInt32(HttpContext.Current.Session[Common.Constant.CODE_SESSION_USERID]);


            if (id != null)
                item = (from i in ctx.UserItems where i.Id == id select i).FirstOrDefault();
            if (id != null && item != null)
                return item;

            return null;


        }
        public static UserItem Login(entitiesEvolveCentral ctx, string username, string password)
        {
            password = Common.Encryption.EncryptString(password);
            UserItem item = new UserItem();

            item = (from i in ctx.UserItems where i.Username == username && i.Password == password orderby i.Name ascending select i).FirstOrDefault();
            if (item != null)
                return item;

            return null;


        }
        public static bool Save(entitiesEvolveCentral ctx, UserItem item)
        {
            bool success = true;
            int id = item.Id;
            try
            {

                if (id == 0)
                {
                    ctx.UserItems.Add(item);
                }

                ctx.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;

            }
            return success;
        }

        public static bool Delete(int id)
        {
            UserItem item = new UserItem();
            bool success = true;
            try
            {
                using (entitiesEvolveCentral ctx = new entitiesEvolveCentral())
                {
                    item = ctx.UserItems.Find(id);

                    ctx.UserItems.Remove(item);
                    ctx.SaveChanges();


                }
            }
            catch (Exception ex)
            {
                success = false;

            }
            return success;
        }
    }
}