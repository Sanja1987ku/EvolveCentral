﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static class LogDetail
    {
        public static List<LogDetailItem> GetByLog(entitiesEvolveCentral ctx, int id)
        {
            var items = new List<LogDetailItem>();
            items = (from i in ctx.LogDetailItems where i.LogId == id orderby i.Date descending select i).ToList();
            return items;
        }
        public static LogDetailItem GetById(entitiesEvolveCentral ctx, int id)
        {
            var item = new LogDetailItem();
            item = (from i in ctx.LogDetailItems where i.Id == id orderby i.Date descending select i).FirstOrDefault();
            return item;
        }
        }
}