﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static  class Service
    {
        public static List<ServiceItem> GetAll(entitiesEvolveCentral ctx)
        {
            var items = new List<ServiceItem>();
            items = (from i in ctx.ServiceItems orderby i.Name ascending select i).ToList();
            return items;
        }

        public static ServiceItem GetByCode(entitiesEvolveCentral ctx, string clientcode,string servicetypecode)
        {
            var item = new ServiceItem();
            item = (from i in ctx.ServiceItems where i.ClientItem.Code  == clientcode && i.ServiceTypeItem.Code == servicetypecode orderby i.Name ascending select i).FirstOrDefault();
            return item;
        }

        public static ServiceItem GetByID(entitiesEvolveCentral ctx, int id)
        {
            var item = new ServiceItem();
            item = (from i in ctx.ServiceItems where i.Id == id orderby i.Name ascending select i).FirstOrDefault();
            return item;
        }


        public static bool Save(entitiesEvolveCentral ctx, ServiceItem item)
        {
            try
            {
                if (item.Id == 0)
                {
                    ctx.ServiceItems.Add(item);
                }

                ctx.SaveChanges();

            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }

        public static bool Delete(entitiesEvolveCentral ctx, int id)
        {
            var item = new ServiceItem();
            try
            {

                item = ctx.ServiceItems.Find(id);
                ctx.ServiceItems.Remove(item);
                ctx.SaveChanges();
            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }
    }
}