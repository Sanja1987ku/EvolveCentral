﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static  class Role
    {
        public static List<RoleItem> GetAll(entitiesEvolveCentral ctx)
        {
            var items = new List<RoleItem>();           
                items = (from i in ctx.RoleItems orderby i.Name ascending select i).ToList();
         return items;
        }
        public static RoleItem GetByID(entitiesEvolveCentral ctx, int id)
        {
            var item = new RoleItem();
            item = (from i in ctx.RoleItems where i.Id == id orderby i.Name ascending select i).FirstOrDefault();
            return item;
        }
    }
}