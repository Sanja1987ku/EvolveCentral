﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static  class ServiceDetail
    {
        public static List<ServiceDetailItem> GetByService(entitiesEvolveCentral ctx, int id)
        {
            var items = new List<ServiceDetailItem>();
            items = (from i in ctx.ServiceDetailItems where i.ServiceId == id orderby i.Sequence ascending select i).ToList();
            return items;
        }

        public static ServiceDetailItem GetByID(entitiesEvolveCentral ctx, int id)
        {
            var item = new ServiceDetailItem();
            item = (from i in ctx.ServiceDetailItems where i.Id == id orderby i.Name ascending select i).FirstOrDefault();
            return item;
        }

        public static bool Save(entitiesEvolveCentral ctx, ServiceDetailItem item)
        {
            try
            {
                if (item.Id == 0)
                {
                    ctx.ServiceDetailItems.Add(item);
                }

                ctx.SaveChanges();

            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }

        public static bool Delete(entitiesEvolveCentral ctx, int id)
        {
            var item = new ServiceDetailItem();
            try
            {

                item = ctx.ServiceDetailItems.Find(id);
                ctx.ServiceDetailItems.Remove(item);
                ctx.SaveChanges();
            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }
    }
}