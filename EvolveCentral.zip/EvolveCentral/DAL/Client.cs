﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static  class Client
    {
        public static List<ClientItem> GetAll(entitiesEvolveCentral ctx)
        {
            var items = new List<ClientItem>();
            items = (from i in ctx.ClientItems orderby i.Name ascending select i).ToList();
            return items;
        }

        public static ClientItem GetByID(entitiesEvolveCentral ctx, int id)
        {
            var item = new ClientItem();
            item = (from i in ctx.ClientItems where i.Id == id orderby i.Name ascending select i).FirstOrDefault();
            return item;
        }

        public static bool Save(entitiesEvolveCentral ctx, ClientItem item)
        {         
            try
            {
                if (item.Id == 0)
                {
                    ctx.ClientItems.Add(item);
                }

                ctx.SaveChanges();

            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }

        public static bool Delete(entitiesEvolveCentral ctx, int id)
        {
            var item = new ClientItem();       
            try
            {

                item = ctx.ClientItems.Find(id);
                ctx.ClientItems.Remove(item);
                    ctx.SaveChanges();                
            }
            catch (Exception ex)
            {
                return false;

            }
            return true;
        }
    }
}