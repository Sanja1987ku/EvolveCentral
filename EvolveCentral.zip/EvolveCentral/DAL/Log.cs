﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolveCentral.DAL
{
    public static  class Log
    {
        public static List<LogItem> GetAll(entitiesEvolveCentral ctx)
        {
            var items = new List<LogItem>();
            items = (from i in ctx.LogItems orderby i.Date descending select i).ToList();
            return items;
        }

        }
}