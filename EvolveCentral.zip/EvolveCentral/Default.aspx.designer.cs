﻿public partial class Default {

    protected global::System.Web.UI.HtmlControls.HtmlForm form1;

    protected global::Telerik.Web.UI.RadScriptManager RadScriptManager1;

    protected global::Telerik.Web.UI.RadStyleSheetManager RadStyleSheetManager1;

    protected global::Telerik.Web.UI.RadAjaxManager RadAjaxManager1;

}
